import 'package:flutter/material.dart';
import 'package:ngopi_asu/common/app_routes.dart';

  class ForgotPassword extends StatefulWidget {
    const ForgotPassword({super.key});

    @override
    State<ForgotPassword> createState() => _ForgotPasswordState();
  }

  class _ForgotPasswordState extends State<ForgotPassword> {

    @override
    Widget build(BuildContext context) {
      return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: const Text('Sign Your Account'),
          centerTitle: true,
        ),
      );
    }
  }